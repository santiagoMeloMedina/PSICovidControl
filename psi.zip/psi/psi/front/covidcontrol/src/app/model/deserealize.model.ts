
export interface Deserealizable {
    deserealize(input: any): this;
}