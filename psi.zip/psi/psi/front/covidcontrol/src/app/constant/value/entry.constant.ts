
export const CONSTANTS = {
    OPTIONS: {
        YES: "SI",
        NO: "NO"
    }
}
