
export const CONSTANTS = {
    COLUMN: [
        "ID Ciudadano",
        "Nombres",
        "Apellidos",
        "Fecha",
        "Hora",
        "Resultado"
    ]
}