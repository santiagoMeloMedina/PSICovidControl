
export const CONSTANTS = {
    REROUTE: {
        MAIN: "dashboard",
        DASHBOARD: "",
        ENTRY: "dashboard",
        EXAM: "dashboard",
        C_ACCOUNT: "dashboard",
        ENABLE: "dashboard",
        AUTORIZE: "dashboard",
        R_EXAM: "dashboard",
        PARAMETER: "dashboard",
        QR: "dashboard"
    }
}