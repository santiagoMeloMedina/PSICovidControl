
export const CONSTANTS = {
    NAV: {
        HOME: {
            NAME: "Inicio",
            LINK: ""
        },
        MISION: {
            NAME: "Misión",
            LINK: "mision"
        },
        CONTACT: {
            NAME: "Contacto",
            LINK: "contact"
        }
    }
}