
export const CONSTANTS = {
    TYPES: {
        CATEGORY: {
            NAME: "Categoria"
        },
        DOCUMENT: {
            NAME: "Documento"
        },
        QUARANTINE: {
            NAME: "Cuarentena"
        },
        NEIGHBORHOOD: {
            NAME: "Barrio"
        }
    }
}