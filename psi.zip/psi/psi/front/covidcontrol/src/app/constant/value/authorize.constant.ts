
export const CONSTANTS = {
    COLUMN: [
        "Documento",
        "Rol",
        "Nombre",
        "Apellidos",
        "Estado",
        "Usuario",
        "Municipio",
        "Departamento",
        "Acción"
    ]
}
