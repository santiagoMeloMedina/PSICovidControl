
export const CONSTANTS = {
    COLUMN: [
        "ID Ciudadano",
        "ID EP",
        "Fecha",
        "Hora",
        "Temperatura",
        "Tapabocas",
        "Respuesta",
        "Descripción"
    ]
}