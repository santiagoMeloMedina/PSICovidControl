
export const CONSTANTS = {
    COOKIE: {
        USER: "user"
    },
    ATTR: {
        ROL: "rol",
        USERNAME: "username",
        ID: "id"
    },
    ROLES: {
        ADMIN: "Admin",
        CITIZEN: "Citizen",
        EP: "EP",
        ES: "ES"
    }
}