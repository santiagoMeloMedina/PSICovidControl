import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mision',
  templateUrl: './mision.component.html',
  styleUrls: ['./mision.component.scss']
})
export class MisionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
