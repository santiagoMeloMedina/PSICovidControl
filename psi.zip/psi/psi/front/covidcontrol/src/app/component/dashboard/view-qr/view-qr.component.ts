import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-qr',
  templateUrl: './view-qr.component.html',
  styleUrls: ['./view-qr.component.scss']
})
export class ViewQrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
