
ROLES = {
    "ADMIN": "Admin",
    "CITIZEN": "Citizen",
    "EP": "EP",
    "ES": "ES"
}