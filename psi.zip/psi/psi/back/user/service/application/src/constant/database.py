
PORT = 27017
NAME = "UserDB"
HOST = "user_db"

USER = "admin"
PASSWORD = "admin"