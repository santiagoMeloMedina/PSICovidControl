
EMPTY = {}