
SECRET_KEY = "user"
NAME = "token"

PAYLOAD = {
    "ID": "id",
    "USERNAME": "username",
    "ROLE": "rol"
}