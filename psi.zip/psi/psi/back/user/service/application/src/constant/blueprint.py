
USER = {
    "ALIAS": "user"
}

CITIZEN = {
    "ALIAS": "citizen"
}

EP = {
    "ALIAS": "ep"
}

ES = {
    "ALIAS": "es"
}

ADMIN = {
    "ALIAS": "admin"
}